import 'package:flutter_test/flutter_test.dart';
import 'package:hissa/features/calculator/domain/bill_calculator.dart';

void main() {
  group('BillCalculator Tests', () {
    const calculator = BillCalculator();

    test('calculates bill without GST or tip', () {
      final result = calculator.calculate(
        billAmount: 1000,
        peopleCount: 4,
        gstPercentage: 0,
        tipPercentage: 0,
        currencyCode: 'INR',
      );

      expect(result.totalAmount, 1000);
      expect(result.amountPerPerson, 250);
    });

    test('calculates GST and tip correctly', () {
      final result = calculator.calculate(
        billAmount: 1000,
        peopleCount: 4,
        gstPercentage: 5,
        tipPercentage: 10,
        currencyCode: 'INR',
      );

      expect(result.gstAmount, 50);
      expect(result.tipAmount, 105);
      expect(result.totalAmount, 1155);
      expect(result.amountPerPerson, 288.75);
    });
  });
}
