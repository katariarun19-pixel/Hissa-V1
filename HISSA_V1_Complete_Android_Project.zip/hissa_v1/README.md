# HISSA V1

Simple and smart bill splitting Flutter application.

## Features
- Bill splitting
- GST and tip calculation
- Multiple currencies
- Persistent calculation history with Hive
- Auto-save control
- Light, dark and system themes
- Default currency preference
- Reset for a fresh calculation
- Clear-history confirmation

## Run
```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

## Note
Run `flutter create .` once if opening this source-only package in a fresh environment and platform folders are missing.
