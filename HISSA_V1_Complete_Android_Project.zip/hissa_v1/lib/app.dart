import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'core/theme/hissa_theme.dart';
import 'features/navigation/presentation/main_navigation_screen.dart';
import 'features/settings/presentation/providers/preferences_provider.dart';

class HissaApp extends ConsumerWidget {
  const HissaApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final preferences = ref.watch(preferencesProvider);

    final themeMode = switch (preferences.themeMode) {
      'light' => ThemeMode.light,
      'dark' => ThemeMode.dark,
      _ => ThemeMode.system,
    };

    return MaterialApp(
      title: 'HISSA',
      debugShowCheckedModeBanner: false,
      theme: HissaTheme.lightTheme,
      darkTheme: HissaTheme.darkTheme,
      themeMode: themeMode,
      home: const MainNavigationScreen(),
    );
  }
}
