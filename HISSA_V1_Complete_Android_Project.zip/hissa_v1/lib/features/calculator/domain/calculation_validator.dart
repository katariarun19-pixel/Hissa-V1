class CalculationValidator {
  CalculationValidator._();

  static String? validateAmount(double? amount) {
    if (amount == null) return 'Please enter a bill amount';
    if (amount <= 0) return 'Bill amount must be greater than 0';
    return null;
  }

  static String? validatePeople(int peopleCount) {
    if (peopleCount < 1) return 'At least one person is required';
    return null;
  }
}
