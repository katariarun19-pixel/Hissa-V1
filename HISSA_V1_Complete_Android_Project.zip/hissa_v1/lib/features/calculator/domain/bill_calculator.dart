import '../../../models/bill_calculation.dart';

class BillCalculator {
  const BillCalculator();

  BillCalculation calculate({
    required double billAmount,
    required int peopleCount,
    required double gstPercentage,
    required double tipPercentage,
    required String currencyCode,
  }) {
    final gstAmount = billAmount * gstPercentage / 100;
    final amountAfterGst = billAmount + gstAmount;
    final tipAmount = amountAfterGst * tipPercentage / 100;
    final totalAmount = amountAfterGst + tipAmount;
    final amountPerPerson = totalAmount / peopleCount;

    return BillCalculation(
      billAmount: billAmount,
      peopleCount: peopleCount,
      gstPercentage: gstPercentage,
      tipPercentage: tipPercentage,
      gstAmount: gstAmount,
      tipAmount: tipAmount,
      totalAmount: totalAmount,
      amountPerPerson: amountPerPerson,
      currencyCode: currencyCode,
    );
  }
}
