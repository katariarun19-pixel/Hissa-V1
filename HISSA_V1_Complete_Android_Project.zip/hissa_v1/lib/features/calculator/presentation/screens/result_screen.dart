import 'package:flutter/material.dart';
import '../../../../core/constants/currency_constants.dart';
import '../../../../core/utils/currency_formatter.dart';
import '../../../../models/bill_calculation.dart';

class ResultScreen extends StatelessWidget {
  final BillCalculation calculation;
  final VoidCallback? onNewCalculation;

  const ResultScreen({
    super.key,
    required this.calculation,
    this.onNewCalculation,
  });

  @override
  Widget build(BuildContext context) {
    final currency = CurrencyConstants.getByCode(calculation.currencyCode);
    String money(double amount) => CurrencyFormatter.format(amount, currency);

    return Scaffold(
      appBar: AppBar(title: const Text('Your HISSA')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 20),
              Text('Each Person Pays', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 12),
              Text(
                money(calculation.amountPerPerson),
                style: Theme.of(context).textTheme.displayMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              Text('${calculation.peopleCount} people'),
              const SizedBox(height: 40),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      _row(context, 'Bill Amount', money(calculation.billAmount)),
                      const SizedBox(height: 16),
                      _row(context, 'GST (${calculation.gstPercentage.toInt()}%)', money(calculation.gstAmount)),
                      const SizedBox(height: 16),
                      _row(context, 'Tip (${calculation.tipPercentage.toInt()}%)', money(calculation.tipAmount)),
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 16),
                        child: Divider(),
                      ),
                      _row(context, 'Total Amount', money(calculation.totalAmount), bold: true),
                    ],
                  ),
                ),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    onNewCalculation?.call();
                    Navigator.pop(context);
                  },
                  child: const Text('NEW CALCULATION'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _row(BuildContext context, String label, String value, {bool bold = false}) {
    final style = bold
        ? Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)
        : Theme.of(context).textTheme.bodyLarge;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [Expanded(child: Text(label, style: style)), const SizedBox(width: 12), Text(value, style: style)],
    );
  }
}
