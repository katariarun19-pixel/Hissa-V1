import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/currency_constants.dart';
import '../../../../models/history_item.dart';
import '../../../history/presentation/providers/history_provider.dart';
import '../../../settings/presentation/providers/preferences_provider.dart';
import '../providers/calculation_provider.dart';
import 'result_screen.dart';

class CalculatorScreen extends ConsumerStatefulWidget {
  const CalculatorScreen({super.key});

  @override
  ConsumerState<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends ConsumerState<CalculatorScreen> {
  final _amountController = TextEditingController();
  bool _initialCurrencyApplied = false;

  @override
  void dispose() {
    _amountController.dispose();
    super.dispose();
  }

  void _applyDefaultCurrencyIfNeeded(String currency) {
    if (_initialCurrencyApplied) return;
    _initialCurrencyApplied = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        ref.read(calculationProvider.notifier).updateCurrency(currency);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final preferences = ref.watch(preferencesProvider);
    _applyDefaultCurrencyIfNeeded(preferences.defaultCurrency);

    final state = ref.watch(calculationProvider);
    final notifier = ref.read(calculationProvider.notifier);
    final currency = CurrencyConstants.getByCode(state.currencyCode);

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            Text('HISSA', style: Theme.of(context).textTheme.headlineLarge),
            const SizedBox(height: 4),
            Text('Split your bill easily', style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 32),

            _title(context, 'Currency'),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: state.currencyCode,
              items: CurrencyConstants.supportedCurrencies.map(
                (item) => DropdownMenuItem(
                  value: item.code,
                  child: Text('${item.symbol} ${item.code}'),
                ),
              ).toList(),
              onChanged: (value) {
                if (value != null) notifier.updateCurrency(value);
              },
            ),

            const SizedBox(height: 24),
            _title(context, 'Bill Amount'),
            const SizedBox(height: 8),
            TextField(
              controller: _amountController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              onChanged: (value) => notifier.updateBillAmount(double.tryParse(value)),
              decoration: InputDecoration(
                prefixText: '${currency.symbol} ',
                hintText: '0.00',
                errorText: state.errorMessage,
              ),
            ),

            const SizedBox(height: 24),
            _title(context, 'Number of People'),
            const SizedBox(height: 8),
            _PeopleCounter(
              count: state.peopleCount,
              onDecrease: notifier.decreasePeople,
              onIncrease: notifier.increasePeople,
            ),

            const SizedBox(height: 24),
            _title(context, 'GST'),
            const SizedBox(height: 8),
            _PercentageSelector(
              values: const [0, 5, 12, 18],
              selectedValue: state.gstPercentage,
              onSelected: notifier.updateGst,
            ),

            const SizedBox(height: 24),
            _title(context, 'Tip'),
            const SizedBox(height: 8),
            _PercentageSelector(
              values: const [0, 5, 10, 15],
              selectedValue: state.tipPercentage,
              onSelected: notifier.updateTip,
            ),

            const SizedBox(height: 40),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _calculate(context),
                child: const Text('BAANT DO'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _title(BuildContext context, String title) {
    return Text(title, style: Theme.of(context).textTheme.titleMedium);
  }

  Future<void> _calculate(BuildContext context) async {
    final notifier = ref.read(calculationProvider.notifier);
    if (!notifier.calculate()) return;

    final result = ref.read(calculationProvider).result!;
    final preferences = ref.read(preferencesProvider);

    if (preferences.autoSaveHistory) {
      final now = DateTime.now();
      await ref.read(historyProvider.notifier).add(
        HistoryItem(
          id: now.microsecondsSinceEpoch.toString(),
          calculation: result,
          createdAt: now,
        ),
      );
    }

    if (!context.mounted) return;

    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ResultScreen(
          calculation: result,
          onNewCalculation: () {
            _amountController.clear();
            notifier.reset(currencyCode: preferences.defaultCurrency);
          },
        ),
      ),
    );
  }
}

class _PeopleCounter extends StatelessWidget {
  final int count;
  final VoidCallback onDecrease;
  final VoidCallback onIncrease;

  const _PeopleCounter({
    required this.count,
    required this.onDecrease,
    required this.onIncrease,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          IconButton(onPressed: onDecrease, icon: const Icon(Icons.remove)),
          Text(count.toString(), style: Theme.of(context).textTheme.headlineSmall),
          IconButton(onPressed: onIncrease, icon: const Icon(Icons.add)),
        ],
      ),
    );
  }
}

class _PercentageSelector extends StatelessWidget {
  final List<double> values;
  final double selectedValue;
  final ValueChanged<double> onSelected;

  const _PercentageSelector({
    required this.values,
    required this.selectedValue,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: values.map((value) => ChoiceChip(
        label: Text('${value.toInt()}%'),
        selected: value == selectedValue,
        onSelected: (_) => onSelected(value),
      )).toList(),
    );
  }
}
