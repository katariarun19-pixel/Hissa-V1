import '../../../../models/bill_calculation.dart';

class CalculationState {
  final double? billAmount;
  final int peopleCount;
  final double gstPercentage;
  final double tipPercentage;
  final String currencyCode;
  final BillCalculation? result;
  final String? errorMessage;

  const CalculationState({
    this.billAmount,
    this.peopleCount = 2,
    this.gstPercentage = 0,
    this.tipPercentage = 0,
    this.currencyCode = 'INR',
    this.result,
    this.errorMessage,
  });

  CalculationState copyWith({
    double? billAmount,
    int? peopleCount,
    double? gstPercentage,
    double? tipPercentage,
    String? currencyCode,
    BillCalculation? result,
    String? errorMessage,
    bool clearResult = false,
    bool clearError = false,
  }) {
    return CalculationState(
      billAmount: billAmount ?? this.billAmount,
      peopleCount: peopleCount ?? this.peopleCount,
      gstPercentage: gstPercentage ?? this.gstPercentage,
      tipPercentage: tipPercentage ?? this.tipPercentage,
      currencyCode: currencyCode ?? this.currencyCode,
      result: clearResult ? null : result ?? this.result,
      errorMessage: clearError ? null : errorMessage ?? this.errorMessage,
    );
  }
}
