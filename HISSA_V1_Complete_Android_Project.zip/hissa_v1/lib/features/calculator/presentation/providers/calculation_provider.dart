import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/bill_calculator.dart';
import '../../domain/calculation_validator.dart';
import 'calculation_state.dart';

final calculationProvider =
    NotifierProvider<CalculationNotifier, CalculationState>(
  CalculationNotifier.new,
);

class CalculationNotifier extends Notifier<CalculationState> {
  final BillCalculator _calculator = const BillCalculator();

  @override
  CalculationState build() => const CalculationState();

  void updateBillAmount(double? amount) {
    state = state.copyWith(
      billAmount: amount,
      clearResult: true,
      clearError: true,
    );
  }

  void increasePeople() {
    state = state.copyWith(
      peopleCount: state.peopleCount + 1,
      clearResult: true,
    );
  }

  void decreasePeople() {
    if (state.peopleCount <= 1) return;
    state = state.copyWith(
      peopleCount: state.peopleCount - 1,
      clearResult: true,
    );
  }

  void updateGst(double value) {
    state = state.copyWith(gstPercentage: value, clearResult: true);
  }

  void updateTip(double value) {
    state = state.copyWith(tipPercentage: value, clearResult: true);
  }

  void updateCurrency(String code) {
    state = state.copyWith(currencyCode: code, clearResult: true);
  }

  bool calculate() {
    final amountError = CalculationValidator.validateAmount(state.billAmount);
    if (amountError != null) {
      state = state.copyWith(errorMessage: amountError);
      return false;
    }

    final peopleError = CalculationValidator.validatePeople(state.peopleCount);
    if (peopleError != null) {
      state = state.copyWith(errorMessage: peopleError);
      return false;
    }

    final result = _calculator.calculate(
      billAmount: state.billAmount!,
      peopleCount: state.peopleCount,
      gstPercentage: state.gstPercentage,
      tipPercentage: state.tipPercentage,
      currencyCode: state.currencyCode,
    );

    state = state.copyWith(result: result, clearError: true);
    return true;
  }

  void reset({String currencyCode = 'INR'}) {
    state = CalculationState(currencyCode: currencyCode);
  }
}
