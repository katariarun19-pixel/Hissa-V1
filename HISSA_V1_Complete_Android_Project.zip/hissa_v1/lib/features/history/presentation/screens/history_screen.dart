import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/currency_constants.dart';
import '../../../../core/utils/currency_formatter.dart';
import '../providers/history_provider.dart';

class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(historyProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        actions: [
          if (history.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: () async {
                final confirmed = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('Clear History?'),
                    content: const Text('All saved calculations will be deleted permanently.'),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: const Text('Cancel'),
                      ),
                      FilledButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text('Clear'),
                      ),
                    ],
                  ),
                );
                if (confirmed == true) {
                  await ref.read(historyProvider.notifier).clearAll();
                }
              },
            ),
        ],
      ),
      body: history.isEmpty
          ? const Center(child: Text('No calculations yet'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: history.length,
              itemBuilder: (context, index) {
                final item = history[index];
                final calculation = item.calculation;
                final currency = CurrencyConstants.getByCode(calculation.currencyCode);
                final perPerson = CurrencyFormatter.format(calculation.amountPerPerson, currency);
                final total = CurrencyFormatter.format(calculation.totalAmount, currency);

                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.calculate_outlined),
                    title: Text('$perPerson per person'),
                    subtitle: Text('${calculation.peopleCount} people • Total $total'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => ref.read(historyProvider.notifier).delete(item.id),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
