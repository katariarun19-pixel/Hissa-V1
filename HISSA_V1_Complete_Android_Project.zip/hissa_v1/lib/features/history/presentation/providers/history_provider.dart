import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/storage/hissa_storage.dart';
import '../../../../models/bill_calculation.dart';
import '../../../../models/history_item.dart';

final historyProvider =
    NotifierProvider<HistoryNotifier, List<HistoryItem>>(
  HistoryNotifier.new,
);

class HistoryNotifier extends Notifier<List<HistoryItem>> {
  @override
  List<HistoryItem> build() {
    final items = <HistoryItem>[];

    for (final value in HissaStorage.historyBox.values) {
      final data = Map<String, dynamic>.from(value as Map);
      items.add(
        HistoryItem(
          id: data['id'] as String,
          createdAt: DateTime.parse(data['createdAt'] as String),
          calculation: BillCalculation(
            billAmount: (data['billAmount'] as num).toDouble(),
            peopleCount: (data['peopleCount'] as num).toInt(),
            gstPercentage: (data['gstPercentage'] as num).toDouble(),
            tipPercentage: (data['tipPercentage'] as num).toDouble(),
            gstAmount: (data['gstAmount'] as num).toDouble(),
            tipAmount: (data['tipAmount'] as num).toDouble(),
            totalAmount: (data['totalAmount'] as num).toDouble(),
            amountPerPerson: (data['amountPerPerson'] as num).toDouble(),
            currencyCode: data['currencyCode'] as String,
          ),
        ),
      );
    }

    items.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return items;
  }

  Future<void> add(HistoryItem item) async {
    await HissaStorage.historyBox.put(item.id, {
      'id': item.id,
      'createdAt': item.createdAt.toIso8601String(),
      'billAmount': item.calculation.billAmount,
      'peopleCount': item.calculation.peopleCount,
      'gstPercentage': item.calculation.gstPercentage,
      'tipPercentage': item.calculation.tipPercentage,
      'gstAmount': item.calculation.gstAmount,
      'tipAmount': item.calculation.tipAmount,
      'totalAmount': item.calculation.totalAmount,
      'amountPerPerson': item.calculation.amountPerPerson,
      'currencyCode': item.calculation.currencyCode,
    });

    state = [item, ...state];
  }

  Future<void> delete(String id) async {
    await HissaStorage.historyBox.delete(id);
    state = state.where((item) => item.id != id).toList();
  }

  Future<void> clearAll() async {
    await HissaStorage.historyBox.clear();
    state = [];
  }
}
