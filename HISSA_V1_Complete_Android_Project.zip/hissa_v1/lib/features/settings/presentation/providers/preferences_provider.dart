import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/storage/hissa_storage.dart';

class AppPreferences {
  final String defaultCurrency;
  final bool autoSaveHistory;
  final String themeMode;

  const AppPreferences({
    this.defaultCurrency = 'INR',
    this.autoSaveHistory = true,
    this.themeMode = 'system',
  });

  AppPreferences copyWith({
    String? defaultCurrency,
    bool? autoSaveHistory,
    String? themeMode,
  }) {
    return AppPreferences(
      defaultCurrency: defaultCurrency ?? this.defaultCurrency,
      autoSaveHistory: autoSaveHistory ?? this.autoSaveHistory,
      themeMode: themeMode ?? this.themeMode,
    );
  }
}

final preferencesProvider =
    NotifierProvider<PreferencesNotifier, AppPreferences>(
  PreferencesNotifier.new,
);

class PreferencesNotifier extends Notifier<AppPreferences> {
  @override
  AppPreferences build() {
    final box = HissaStorage.preferencesBox;
    return AppPreferences(
      defaultCurrency: box.get('defaultCurrency', defaultValue: 'INR') as String,
      autoSaveHistory: box.get('autoSaveHistory', defaultValue: true) as bool,
      themeMode: box.get('themeMode', defaultValue: 'system') as String,
    );
  }

  Future<void> updateCurrency(String currency) async {
    await HissaStorage.preferencesBox.put('defaultCurrency', currency);
    state = state.copyWith(defaultCurrency: currency);
  }

  Future<void> toggleAutoSave(bool value) async {
    await HissaStorage.preferencesBox.put('autoSaveHistory', value);
    state = state.copyWith(autoSaveHistory: value);
  }

  Future<void> updateTheme(String theme) async {
    await HissaStorage.preferencesBox.put('themeMode', theme);
    state = state.copyWith(themeMode: theme);
  }
}
