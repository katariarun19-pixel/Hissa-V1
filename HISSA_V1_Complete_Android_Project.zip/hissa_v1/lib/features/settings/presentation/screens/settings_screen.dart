import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/constants/currency_constants.dart';
import '../providers/preferences_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final preferences = ref.watch(preferencesProvider);
    final notifier = ref.read(preferencesProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Preferences', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          ListTile(
            leading: const Icon(Icons.currency_exchange),
            title: const Text('Default Currency'),
            subtitle: Text(preferences.defaultCurrency),
            onTap: () => _showCurrencyDialog(context, notifier),
          ),
          SwitchListTile(
            secondary: const Icon(Icons.history),
            title: const Text('Auto-save History'),
            value: preferences.autoSaveHistory,
            onChanged: notifier.toggleAutoSave,
          ),
          const Divider(height: 40),
          Text('Appearance', style: Theme.of(context).textTheme.titleMedium),
          ListTile(
            leading: const Icon(Icons.dark_mode_outlined),
            title: const Text('Theme'),
            subtitle: Text(preferences.themeMode),
            onTap: () => _showThemeDialog(context, notifier),
          ),
          const Divider(height: 40),
          Text('About', style: Theme.of(context).textTheme.titleMedium),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('HISSA'),
            subtitle: Text('Simple and smart bill splitting'),
          ),
          const ListTile(
            leading: Icon(Icons.code),
            title: Text('Version'),
            subtitle: Text('1.0.0'),
          ),
        ],
      ),
    );
  }

  void _showCurrencyDialog(BuildContext context, PreferencesNotifier notifier) {
    showDialog(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('Default Currency'),
        children: CurrencyConstants.supportedCurrencies.map(
          (currency) => SimpleDialogOption(
            onPressed: () {
              notifier.updateCurrency(currency.code);
              Navigator.pop(context);
            },
            child: Text('${currency.symbol} ${currency.name}'),
          ),
        ).toList(),
      ),
    );
  }

  void _showThemeDialog(BuildContext context, PreferencesNotifier notifier) {
    showDialog(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('Choose Theme'),
        children: [
          SimpleDialogOption(
            onPressed: () {
              notifier.updateTheme('system');
              Navigator.pop(context);
            },
            child: const Text('System Default'),
          ),
          SimpleDialogOption(
            onPressed: () {
              notifier.updateTheme('light');
              Navigator.pop(context);
            },
            child: const Text('Light'),
          ),
          SimpleDialogOption(
            onPressed: () {
              notifier.updateTheme('dark');
              Navigator.pop(context);
            },
            child: const Text('Dark'),
          ),
        ],
      ),
    );
  }
}
