import 'bill_calculation.dart';

class HistoryItem {
  final String id;
  final BillCalculation calculation;
  final DateTime createdAt;

  const HistoryItem({
    required this.id,
    required this.calculation,
    required this.createdAt,
  });
}
