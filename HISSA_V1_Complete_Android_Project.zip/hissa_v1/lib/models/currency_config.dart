class CurrencyConfig {
  final String code;
  final String name;
  final String symbol;
  final int decimalDigits;

  const CurrencyConfig({
    required this.code,
    required this.name,
    required this.symbol,
    this.decimalDigits = 2,
  });
}
