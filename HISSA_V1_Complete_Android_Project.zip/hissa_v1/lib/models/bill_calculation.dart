class BillCalculation {
  final double billAmount;
  final int peopleCount;
  final double gstPercentage;
  final double tipPercentage;
  final double gstAmount;
  final double tipAmount;
  final double totalAmount;
  final double amountPerPerson;
  final String currencyCode;

  const BillCalculation({
    required this.billAmount,
    required this.peopleCount,
    required this.gstPercentage,
    required this.tipPercentage,
    required this.gstAmount,
    required this.tipAmount,
    required this.totalAmount,
    required this.amountPerPerson,
    required this.currencyCode,
  });
}
