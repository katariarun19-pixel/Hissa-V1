import 'package:flutter/material.dart';

class HissaColors {
  HissaColors._();

  static const primary = Color(0xFF2563EB);
  static const secondary = Color(0xFF10B981);

  static const lightBackground = Color(0xFFF8FAFC);
  static const lightSurface = Colors.white;
  static const darkBackground = Color(0xFF0F172A);
  static const darkSurface = Color(0xFF1E293B);
  static const lightText = Color(0xFF0F172A);
  static const darkText = Color(0xFFF8FAFC);
}
