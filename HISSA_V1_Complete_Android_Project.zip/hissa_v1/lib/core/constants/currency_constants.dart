import '../../models/currency_config.dart';

class CurrencyConstants {
  CurrencyConstants._();

  static const supportedCurrencies = <CurrencyConfig>[
    CurrencyConfig(code: 'INR', name: 'Indian Rupee', symbol: '₹'),
    CurrencyConfig(code: 'USD', name: 'US Dollar', symbol: r'$'),
    CurrencyConfig(code: 'EUR', name: 'Euro', symbol: '€'),
    CurrencyConfig(code: 'GBP', name: 'British Pound', symbol: '£'),
    CurrencyConfig(code: 'AED', name: 'UAE Dirham', symbol: 'د.إ'),
  ];

  static CurrencyConfig getByCode(String code) {
    return supportedCurrencies.firstWhere(
      (currency) => currency.code == code,
      orElse: () => supportedCurrencies.first,
    );
  }
}
