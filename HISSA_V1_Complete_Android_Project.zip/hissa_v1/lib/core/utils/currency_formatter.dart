import 'package:intl/intl.dart';
import '../../models/currency_config.dart';

class CurrencyFormatter {
  CurrencyFormatter._();

  static String format(double amount, CurrencyConfig currency) {
    return NumberFormat.currency(
      symbol: currency.symbol,
      decimalDigits: currency.decimalDigits,
    ).format(amount);
  }
}
