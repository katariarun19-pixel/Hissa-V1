import 'package:hive_flutter/hive_flutter.dart';

class HissaStorage {
  HissaStorage._();

  static const historyBoxName = 'history';
  static const preferencesBoxName = 'preferences';

  static Future<void> initialize() async {
    await Hive.openBox(historyBoxName);
    await Hive.openBox(preferencesBoxName);
  }

  static Box get historyBox => Hive.box(historyBoxName);
  static Box get preferencesBox => Hive.box(preferencesBoxName);
}
